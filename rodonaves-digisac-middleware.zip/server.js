const express = require('express');
const axios = require('axios');
const app = express();
app.use(express.json());

const TOKEN = process.env.RODONAVES_TOKEN;

app.post('/consulta-coleta', async (req, res) => {
  try {
    const response = await axios.get('https://pickup-apigateway.rte.com.br/api/v1/pickup', {
      headers: { Authorization: `Bearer ${TOKEN}` }
    });

    const dados = response.data;

    // Exemplo de retorno que pode ser formatado para o Digisac
    return res.status(200).json({
      status: 'sucesso',
      totalColetas: dados.length,
      coletas: dados.slice(0, 5) // retorna as 5 primeiras para exibir
    });
  } catch (error) {
    console.error(error.response?.data || error.message);
    return res.status(500).json({ erro: 'Erro ao consultar coletas' });
  }
});

app.get('/', (req, res) => {
  res.send('Middleware Rodonaves - Digisac está rodando');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor iniciado na porta ${PORT}`);
});
